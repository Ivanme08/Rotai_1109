﻿**IMPORTANT NOTICE:** This repository is moved to <a href="https://aspnetboilerplate.com/" target="_blank">ASP.NET Boilerplate</a> repository and it is deprecated now. Please refer to <a href="https://aspnetboilerplate.com/" target="_blank">ASP.NET Boilerplate</a> repository.


