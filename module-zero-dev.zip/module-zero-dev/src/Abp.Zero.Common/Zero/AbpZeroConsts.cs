﻿namespace Abp.Zero
{
    public class AbpZeroConsts
    {
        /// <summary>
        /// "AbpZero"
        /// </summary>
        public const string LocalizationSourceName = "AbpZero";
    }
}