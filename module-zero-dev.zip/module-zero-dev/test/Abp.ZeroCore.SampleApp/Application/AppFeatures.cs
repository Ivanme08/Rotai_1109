﻿namespace Abp.ZeroCore.SampleApp.Application
{
    public static class AppFeatures
    {
        public const string SimpleBooleanFeature = "SimpleBooleanFeature";
    }
}
