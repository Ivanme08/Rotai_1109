﻿using Abp.Authorization;

namespace Abp.ZeroCore.SampleApp.Application
{
    public class AppAuthorizationProvider : AuthorizationProvider
    {
        public override void SetPermissions(IPermissionDefinitionContext context)
        {
            
        }
    }
}
