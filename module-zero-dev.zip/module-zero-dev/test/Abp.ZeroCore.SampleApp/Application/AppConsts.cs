﻿namespace Abp.ZeroCore.SampleApp.Application
{
    public static class AppConsts
    {
        public const string LocalizationSourceName = "SampleApp";
    }
}
