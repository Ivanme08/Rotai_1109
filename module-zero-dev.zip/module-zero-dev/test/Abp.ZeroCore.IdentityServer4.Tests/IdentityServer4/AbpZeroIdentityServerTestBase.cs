﻿using Abp.TestBase;

namespace Abp.IdentityServer4
{
    public abstract class AbpZeroIdentityServerTestBase : AbpIntegratedTestBase<AbpZeroIdentityServerTestModule>
    {
        
    }
}
